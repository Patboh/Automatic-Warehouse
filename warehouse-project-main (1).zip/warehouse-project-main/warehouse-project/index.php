<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include("head.php");
    ?>
</head>

<body>

    <div class="index-page">
        <div class="title-box">
            <h2>WELCOME TO</h2><br>
            <h1>AUTOMATIC WAREHOUSE SYSTEMS</h1><br>
            <p>Silpakorn University</p>
            <div>
                <div class="btn-signin">
                    <a href="login.php">Sign In</a>
                </div>
            </div>
        </div>
    </div>

</body>

</html>