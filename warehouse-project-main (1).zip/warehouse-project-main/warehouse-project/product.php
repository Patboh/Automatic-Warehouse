        <div class="">
            <li class="box active">C3</li>
            <li class="box ">C2</li>
            <li class="box ">C1</li>
        </div>

        <div>
            <li class="box ">B3</li>
            <li class="box ">B2</li>
            <li class="box ">B1</li>
        </div>

        <div>
            <li class="box ">A3</li>
            <li class="box ">A2</li>
            <li class="box ">A1</li>
        </div>
